 template.helper( 'fn' , function( a , b  ){
        if( b == 'level' ){
            return a>90 ? '优':'中' ;
        }
    });